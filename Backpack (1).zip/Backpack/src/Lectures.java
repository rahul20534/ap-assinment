import java.util.ArrayList;

public class Lectures {
    ArrayList<String> videos=new ArrayList<>();
    ArrayList<String> slides=new ArrayList<>();



}

