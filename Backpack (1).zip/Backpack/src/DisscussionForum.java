public interface DisscussionForum {
public void addComments(String str);
public void viewComments();
}

