import java.util.ArrayList;

public class Assessment {
ArrayList<String> assignments=new ArrayList<>();
ArrayList<String> quizzes=new ArrayList<>();
ArrayList<Integer> maxMarks=new ArrayList<>();
ArrayList<Boolean> closeStatus=new ArrayList<>();
ArrayList<String> comments=new ArrayList<>();

}

